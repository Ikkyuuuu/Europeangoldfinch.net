const { Router } = require('express');
const { createUser } = require('../controllers/userController');

const router = Router();

// TEMP debug: see the body Postman is sending
router.post('/', (req, res, next) => {
    console.log('[DEBUG] /users body:', req.body, 'headers:', req.headers['content-type']);
    return createUser(req, res, next);
});

module.exports = router;